# Praesidium Provisioning Wizard Refactor — Deployment Runbook

**Generated:** 2026-04-29
**Tests:** 57/57 passing locally (pytest, mocked DB and subprocess).
**Files produced:** 14 source files + 5 test files.

This refactor replaces the broken `provision_tenant.py` with a schema-correct
data path, adds pluggable proxy + storage backends, and supports idempotent
retry of the proxy step.

---

## Files in this deliverable

```
infra/                                       (NEW package)
├── __init__.py
├── proxy/
│   ├── __init__.py        get_proxy_backend()
│   ├── base.py            ProxyBackend Protocol
│   ├── local_nginx.py     LocalNginxBackend (appliance, on-prem)
│   └── ssh_rprx.py        SshRprxBackend (HJMM production)
└── storage/
    ├── __init__.py        get_storage_backend()
    ├── base.py            StorageProvisioningBackend Protocol
    ├── local_fs.py        LocalFsBackend (canonical going forward)
    └── cifs_bridge.py     CifsBridgeBackend (DEPRECATED — HJMM/enron/test only)

jobs/                                        (REWRITES)
├── provision_tenant.py    Schema-correct, data-path-only, enqueues proxy job
└── proxy_provision.py     New — separate idempotent retry for the proxy step

modules/admin/
└── provisioning_wizard.py Light fixes: real schema, proxy retry route

tests/
├── infra/
│   ├── test_local_nginx_backend.py
│   ├── test_ssh_rprx_backend.py
│   ├── test_local_fs_backend.py
│   └── test_factories.py
└── jobs/
    ├── test_provision_tenant.py
    └── test_proxy_provision.py
```

---

## Pre-deployment requirements

### Appliance environment

The worker container must have these bind mounts (add to
`docker-compose.proc.yml` if not already present):

```yaml
worker:
  volumes:
    - ./:/app                                          # existing
    - /opt/praesidium-mcp/nginx/sites:/opt/praesidium-mcp/nginx/sites:rw  # NEW
    - /var/run/docker.sock:/var/run/docker.sock:ro     # NEW
    - /mnt/praesidium:/mnt/praesidium:rw               # NEW
    - /etc/letsencrypt:/etc/letsencrypt:ro             # NEW (for proxy_provision cert path resolution)
```

The worker also needs the `docker` CLI binary in its image. If the current
image doesn't include it:

```dockerfile
# In Dockerfile (worker base):
RUN apt-get update && apt-get install -y --no-install-recommends docker.io \
    && rm -rf /var/lib/apt/lists/*
```

(The worker only needs the *client*, not the daemon. `docker.io` package
provides both; that's fine — `dockerd` won't start in a container.)

### Required env vars

In `/opt/praesidium-web/.env` (or `.env.appliance`):

```ini
# Platform admin password — bcrypt hash. Used by /admin/login.
# Generate with:
#   python3 -c 'import bcrypt; print(bcrypt.hashpw(b"YOUR_PASSWORD", bcrypt.gensalt()).decode())'
PLATFORM_ADMIN_PASSWORD_HASH=$2b$12$REPLACE_WITH_REAL_HASH

# Proxy backend selection
PROXY_BACKEND=local                    # 'local' for appliance/on-prem; 'ssh-rprx' for HJMM prod
NGINX_SITES_HOST_DIR=/opt/praesidium-mcp/nginx/sites
NGINX_CONTAINER_NAME=praesidium-nginx
PROXY_LISTEN_IP=10.10.40.75            # appliance DMZ IP
PROXY_UPSTREAM_HOST=172.28.1.3         # praesidium-web on praesidium-edge network
PROXY_UPSTREAM_PORT=8000

# Storage backend selection
STORAGE_BACKEND=local                  # 'local' going forward; 'cifs' only for HJMM/enron/test
STORAGE_LOCAL_ROOT=/mnt/praesidium

# Platform domain (for default tenant subdomain)
PLATFORM_DOMAIN=praesidium-legal.com
```

For HJMM production, override:

```ini
PROXY_BACKEND=ssh-rprx
RPRX_HOST=10.10.40.50
RPRX_SSH_USER=praesidium
RPRX_SSH_KEY=/run/secrets/rprx_ssh_key

# HJMM/enron/test still use cifs:
STORAGE_BACKEND=cifs
CIFS_BRIDGE_URL=http://10.10.60.13:8080
```

### Required filesystem state

Create the storage root if it doesn't exist:

```bash
sudo mkdir -p /mnt/praesidium
sudo chown -R 1000:1000 /mnt/praesidium    # match worker container UID
sudo chmod 755 /mnt/praesidium
```

---

## Deployment steps

### Step 1. Stage files into the repo

The 14 source files go to their canonical locations. From the appliance
shell with the bundle extracted to `/tmp/wizard-refactor/`:

```bash
# Copy infra package into place (new files)
sudo cp -r /tmp/wizard-refactor/infra /opt/praesidium-web/
sudo chown -R dmholmgren:dmholmgren /opt/praesidium-web/infra

# Replace existing files (keep backups)
sudo cp /opt/praesidium-web/jobs/provision_tenant.py \
        /opt/praesidium-web/jobs/provision_tenant.py.bak-$(date +%Y%m%d_%H%M%S)
sudo cp /tmp/wizard-refactor/jobs/provision_tenant.py /opt/praesidium-web/jobs/
sudo cp /tmp/wizard-refactor/jobs/proxy_provision.py /opt/praesidium-web/jobs/

sudo cp /opt/praesidium-web/modules/admin/provisioning_wizard.py \
        /opt/praesidium-web/modules/admin/provisioning_wizard.py.bak-$(date +%Y%m%d_%H%M%S)
sudo cp /tmp/wizard-refactor/modules/admin/provisioning_wizard.py \
        /opt/praesidium-web/modules/admin/

# Tests (optional but recommended)
sudo mkdir -p /opt/praesidium-web/tests/infra /opt/praesidium-web/tests/jobs
sudo cp -r /tmp/wizard-refactor/tests/infra/* /opt/praesidium-web/tests/infra/
sudo cp -r /tmp/wizard-refactor/tests/jobs/test_provision_tenant.py \
           /tmp/wizard-refactor/tests/jobs/test_proxy_provision.py \
           /opt/praesidium-web/tests/jobs/
```

### Step 2. Update env file

Edit `/opt/praesidium-web/.env` and add the variables under
"Pre-deployment requirements" above.

### Step 3. Update worker compose

Edit `/opt/praesidium-web/docker-compose.proc.yml` to add the new bind
mounts (and rebuild image if docker CLI was missing).

### Step 4. Restart the worker

```bash
cd /opt/praesidium-web
sudo docker compose -f docker-compose.proc.yml down worker
sudo docker compose -f docker-compose.proc.yml build worker     # if Dockerfile changed
sudo docker compose -f docker-compose.proc.yml up -d worker

# Verify worker has docker CLI access
sudo docker compose -f docker-compose.proc.yml exec worker docker ps
# Should list praesidium-nginx and friends.
```

### Step 5. Restart web (to load new wizard router)

```bash
sudo docker compose -f docker-compose.appliance.yml restart web
sudo docker compose -f docker-compose.appliance.yml logs --tail 30 web
# Should show clean startup, all imports OK.
```

### Step 6. Run tests inside the container (optional, recommended)

```bash
sudo docker compose -f docker-compose.proc.yml exec worker \
    bash -lc "cd /app && pytest tests/infra/ tests/jobs/ -v"
# Should report 57 passed.
```

### Step 7. Smoke-test by provisioning a tenant

In a browser, log in as a platform admin and navigate to:

```
https://login.hjmmlegal.com/admin/provision/new
```

Provision a test tenant (e.g. slug=`smoke`, firm=`Smoke Test`, feature
pack=`starter`, deployment tier=`dedicated`). The wizard should walk
through 4 steps and show a progress page tracking both the data and proxy
jobs.

After both report complete, verify:

```bash
# tenants row exists with is_active=true
sudo docker exec praesidium-postgres psql -U praesidium -d praesidium -c \
  "SELECT slug, name, is_active, storage_adapter FROM tenants WHERE slug='smoke';"

# vhost file exists
ls -la /opt/praesidium-mcp/nginx/sites/smoke.conf

# storage dir exists
ls -la /mnt/praesidium/smoke/

# Hit the new tenant's URL (cert is the wildcard *.praesidium-legal.com)
curl -I https://smoke.praesidium-legal.com
# Expect 302 → /login or 200.
```

### Step 8. Clean up the smoke tenant

```sql
-- Connect to praesidium DB
DELETE FROM users WHERE tenant_id = (SELECT id FROM tenants WHERE slug='smoke');
DELETE FROM tenant_licenses WHERE tenant_id = (SELECT id FROM tenants WHERE slug='smoke');
DELETE FROM tenant_branding WHERE tenant_id = (SELECT id FROM tenants WHERE slug='smoke');
DELETE FROM tenants WHERE slug='smoke';
```

```bash
sudo rm /opt/praesidium-mcp/nginx/sites/smoke.conf
sudo docker exec praesidium-nginx nginx -s reload
sudo rm -rf /mnt/praesidium/smoke
```

---

## Failure modes & retry

### Data path failure

If `provision_tenant` fails before the proxy step is enqueued:

- The tenants row may exist with `status='suspended'` and `is_active=false`.
- The wizard's progress page shows "data_status: failed" with the error.
- **Recovery:** Investigate the error (DB issue, schema mismatch, etc.),
  fix the underlying cause, manually clean up the partial tenant row
  (see Step 8 above), and re-run the wizard from `/admin/provision/new`.

### Proxy step failure

If `provision_proxy` fails (nginx down, cert path wrong, daemon unreachable):

- The tenants row exists with `is_active=false`.
- The wizard's progress page shows "proxy_status: failed" with the error.
- **Recovery:** Fix the underlying cause (start nginx, fix cert path,
  whatever), then POST to `/admin/provision/retry-proxy/{tenant_id}` —
  this re-enqueues ONLY the proxy job. The data work is not re-run.

### Idempotency contract

Both backends overwrite existing vhost files on `write_vhost`, so retry
is always safe. nginx reload is naturally idempotent. The only side
effect of retrying after a partial success is briefly re-writing a
vhost file with identical content, which is harmless.

---

## Rollback procedure

If the new code misbehaves and you need to revert quickly:

```bash
cd /opt/praesidium-web

# Restore previous versions from .bak files (paths from Step 1)
sudo cp jobs/provision_tenant.py.bak-* jobs/provision_tenant.py
sudo cp modules/admin/provisioning_wizard.py.bak-* \
        modules/admin/provisioning_wizard.py
sudo rm jobs/proxy_provision.py
sudo rm -rf infra/

# Restart web
sudo docker compose -f docker-compose.appliance.yml restart web
```

The old wizard wasn't actually working in production (all three current
tenants were created manually), so the rollback restores broken code.
The right move on failure is to fix forward, not roll back.

---

## What this change unlocks

- Tenant provisioning works end-to-end on the appliance — the original
  goal of this session.
- HJMM production gets a working wizard if `PROXY_BACKEND=ssh-rprx` and
  `STORAGE_BACKEND=cifs` are set; the existing manual SQL pattern
  remains valid as a fallback.
- Future cloud installs add a third proxy backend (e.g. for ELB or
  Cloudflare) without touching the data path.
- The deprecated `cifs` storage adapter is now isolated; new tenants
  default to local FS, and HJMM/enron/test continue to work.
- Idempotent retry semantics mean partial provisioning failures don't
  require database surgery — just hit the retry button.
