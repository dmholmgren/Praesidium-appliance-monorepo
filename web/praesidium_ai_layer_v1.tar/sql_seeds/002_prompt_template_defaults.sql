-- =========================================================================
-- Praesidium AI Layer — Prompt Template Seeds (Platform Defaults)
-- =========================================================================
-- Run after 001_ai_model_routing_defaults.sql
--
-- Extracts the four existing hardcoded prompt sites into versioned database
-- rows per Architectural Constraint #4 (Templates Are Versioned Data).
-- tenant_id NULL = platform default, may be overridden per-tenant.
--
-- Slugs follow module.purpose convention, matching ai_model_routing keys.
-- =========================================================================

BEGIN;

-- -------------------------------------------------------------------------
-- billing.intake_analyze
--   Source: billing/api/intake_api.py:142 (hardcoded)
-- -------------------------------------------------------------------------
WITH t AS (
  INSERT INTO prompt_templates
    (tenant_id, slug, module, purpose, current_version, status, description)
  VALUES
    (NULL, 'billing.intake_analyze', 'billing', 'intake_analyze', 1, 'published',
     'Extract structured fields from intake documents — client name, matter type, court, adverse parties, dates.')
  RETURNING id
)
INSERT INTO prompt_template_versions
  (template_id, version, system_prompt, user_prompt, variables, response_format, notes)
SELECT
  t.id, 1,
  NULL,
  'Analyze this legal document and extract the following fields.
Return ONLY a valid JSON object with these exact keys:

{{
  "client_name": "Full name of the client/plaintiff/party we represent",
  "client_type": "individual or entity",
  "matter_type": "litigation, transactional, real_estate, family, probate, or other",
  "court_name": "Full court name or null",
  "case_number": "Case/cause number or null",
  "judge_name": "Judge name or null",
  "adverse_parties": ["List", "of", "opposing", "party", "names"],
  "cause_of_action": ["List", "of", "causes", "of", "action"],
  "key_dates": [
    {{"name": "Answer Due", "date": "YYYY-MM-DD", "description": "brief description"}},
    {{"name": "Trial", "date": "YYYY-MM-DD", "description": "brief description"}}
  ],
  "filing_date": "YYYY-MM-DD or null",
  "summary": "2-3 sentence description of what this matter is about"
}}

If a field cannot be determined, use null or an empty array.
Do not include any text outside the JSON object.

DOCUMENT:
{document_text}',
  '["document_text"]'::jsonb,
  'json',
  'Doubled braces in literal JSON examples so adapter variable regex does not consume them. Adapter _VAR_RE matches single-brace {name} only.'
FROM t;

-- -------------------------------------------------------------------------
-- admin.timesheet_reconcile
--   Source: admin/timesheet_api.py:358
-- -------------------------------------------------------------------------
WITH t AS (
  INSERT INTO prompt_templates
    (tenant_id, slug, module, purpose, current_version, status, description)
  VALUES
    (NULL, 'admin.timesheet_reconcile', 'admin', 'timesheet_reconcile', 1, 'published',
     'Aggregate billing reconciliation across phone, email, Timeslips, and ai_api_calls sources into attributable billable entries.')
  RETURNING id
)
INSERT INTO prompt_template_versions
  (template_id, version, system_prompt, user_prompt, variables, response_format, notes)
SELECT
  t.id, 1,
  NULL,
  'You are a legal billing assistant helping attorney {user_name} reconstruct their timesheet for {date_from} to {date_to}.

Active matters:
{matter_list}

Raw time entries from all sources (index: [source] date | hours | matter | description):
{entries_summary}

For each entry, respond with a JSON array where each element has:
- index: the entry index number
- matter_id: matched matter ID string or null
- matter_name: matched matter name or null
- hours: suggested hours (float, rounded to nearest 0.25)
- narrative: professional billing narrative (concise, specific, billable)
- confidence: 0.0 to 1.0 confidence score for matter attribution
- notes: brief explanation of your attribution decision

Rules:
1. Match entries to matters based on context clues in descriptions
2. For ai_api_calls entries, try to attribute based on module names
3. For phone entries with no context, leave matter_id null and confidence low
4. Timeslips entries are already attributed — keep their matter, improve narrative only
5. Flag duplicate or overlapping entries in notes
6. Respond ONLY with the JSON array, no other text.',
  '["user_name","date_from","date_to","matter_list","entries_summary"]'::jsonb,
  'json_array',
  'First prompt template with multiple variable placeholders. Variables resolved by adapter _VAR_RE.'
FROM t;

-- -------------------------------------------------------------------------
-- ediscovery.matter_chat (one template, context variant passed as variable)
--   Source: ediscovery/routes/chat.py SYSTEM_PROMPTS dict
-- -------------------------------------------------------------------------
-- Four context-specific system prompts merged into one template with a
-- {context_system_prompt} variable chosen by the caller, plus optional
-- {matter_context} appended.
WITH t AS (
  INSERT INTO prompt_templates
    (tenant_id, slug, module, purpose, current_version, status, description)
  VALUES
    (NULL, 'ediscovery.matter_chat', 'ediscovery', 'matter_chat', 1, 'published',
     'Matter chat assistant. Caller passes context-specific system prompt as a variable; adapter appends matter context block.')
  RETURNING id
)
INSERT INTO prompt_template_versions
  (template_id, version, system_prompt, user_prompt, variables, response_format, notes)
SELECT
  t.id, 1,
  '{context_system_prompt}

Matter context:
{matter_context}',
  '{user_message}',
  '["context_system_prompt","matter_context","user_message"]'::jsonb,
  'text',
  'Chat endpoint uses a multi-turn messages array in the HTTP payload; this template represents single-turn usage. Multi-turn still passes through adapter.call with raw_user_prompt and raw_system_prompt.'
FROM t;

-- -------------------------------------------------------------------------
-- ediscovery.tag_suggest
--   Source: ediscovery/tag_intelligence.py:303
-- -------------------------------------------------------------------------
WITH t AS (
  INSERT INTO prompt_templates
    (tenant_id, slug, module, purpose, current_version, status, description)
  VALUES
    (NULL, 'ediscovery.tag_suggest', 'ediscovery', 'tag_suggest', 1, 'published',
     'Recommend up to 5 review tags for a document, grounded in the matter issue map and existing tag vocabulary.')
  RETURNING id
)
INSERT INTO prompt_template_versions
  (template_id, version, system_prompt, user_prompt, variables, response_format, notes)
SELECT
  t.id, 1,
  NULL,
  'You are a document review tagging engine for a litigation matter.

Document metadata:
{doc_info}

Case theory (issue map):
{issue_map_summary}

Existing tags used in this matter (for consistency):
{existing_tags}

Recommend up to 5 tags for this document. Use existing tag names where applicable.
Return ONLY a JSON array — no preamble, no markdown:
[
  {{
    "name": "tag name",
    "confidence": 0.0-1.0,
    "rationale": "one sentence explanation"
  }}
]

If no tags are appropriate, return []. Only recommend tags with genuine basis.',
  '["doc_info","issue_map_summary","existing_tags"]'::jsonb,
  'json_array',
  'Doubled braces preserve literal JSON schema example.'
FROM t;

COMMIT;
