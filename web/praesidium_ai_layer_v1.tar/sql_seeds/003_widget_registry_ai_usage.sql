-- =========================================================================
-- Praesidium AI Layer — Widget Registry + Layout Seeds
-- =========================================================================
-- Run after 002_prompt_template_defaults.sql.
--
-- Registers three data_panel widgets for AI usage visibility on the billing
-- landing page, and adds them to the default billing_home layout.
--
-- Widget categories are constrained to the check constraint values —
-- 'billing', 'firm' are both valid. my_matters is 'billing', the firm-scope
-- widgets are 'firm' per widget_registry_category_check.
-- =========================================================================

BEGIN;

-- -------------------------------------------------------------------------
-- Widget: ai_usage_my_matters
-- -------------------------------------------------------------------------
INSERT INTO widget_registry
  (tenant_id, widget_slug, widget_name, category, widget_type,
   data_source, render_template, target_route,
   source_platform, default_size, resizable,
   permission_level, feature_flag, config_schema, is_platform_standard)
VALUES
  (NULL, 'ai_usage_my_matters', 'My AI Usage', 'billing', 'data_panel',
   'modules.intelligence.widget_service.get_my_matters_ai_usage',
   'ai_usage_my_matters.html',
   NULL,
   'praesidium', 'large', TRUE,
   'attorney', NULL,
   '{}'::jsonb, TRUE);

-- -------------------------------------------------------------------------
-- Widget: ai_usage_firm   (partner-gated)
-- -------------------------------------------------------------------------
INSERT INTO widget_registry
  (tenant_id, widget_slug, widget_name, category, widget_type,
   data_source, render_template, target_route,
   source_platform, default_size, resizable,
   permission_level, feature_flag, config_schema, is_platform_standard)
VALUES
  (NULL, 'ai_usage_firm', 'Firm AI Usage', 'firm', 'data_panel',
   'modules.intelligence.widget_service.get_firm_ai_usage',
   'ai_usage_firm.html',
   NULL,
   'praesidium', 'full-width', TRUE,
   'partner', NULL,
   '{}'::jsonb, TRUE);

-- -------------------------------------------------------------------------
-- Widget: ai_unallocated_review   (partner-gated)
-- -------------------------------------------------------------------------
INSERT INTO widget_registry
  (tenant_id, widget_slug, widget_name, category, widget_type,
   data_source, render_template, target_route,
   source_platform, default_size, resizable,
   permission_level, feature_flag, config_schema, is_platform_standard)
VALUES
  (NULL, 'ai_unallocated_review', 'Unallocated AI Charges', 'firm', 'data_panel',
   'modules.intelligence.widget_service.get_unallocated_review',
   'ai_unallocated_review.html',
   NULL,
   'praesidium', 'medium', TRUE,
   'partner', NULL,
   '{}'::jsonb, TRUE);

-- -------------------------------------------------------------------------
-- Layout placement — billing_home default tab
-- -------------------------------------------------------------------------
-- This upserts against every tenant's default billing_home layout. If the
-- tenant already has a default billing_home row, we append to its positions;
-- otherwise we create a new one. Idempotent: checks whether each widget_slug
-- is already present before appending.
--
-- Positions use a simple grid model: {"slug": ..., "col": 1-12, "row": N}
-- consistent with layout_loader.py.
-- -------------------------------------------------------------------------

DO $$
DECLARE
  t RECORD;
  existing jsonb;
  new_positions jsonb;
BEGIN
  FOR t IN SELECT DISTINCT tenant_id FROM matters LOOP
    -- Find or create billing_home default layout for this tenant
    SELECT widget_positions INTO existing
      FROM layout_registry
     WHERE TRIM(tenant_id) = TRIM(t.tenant_id)
       AND layout_slug = 'billing_home'
       AND tab_slug = 'default'
       AND is_default = TRUE
       AND user_id IS NULL
     LIMIT 1;

    IF existing IS NULL THEN
      -- Create new layout with all three widgets
      INSERT INTO layout_registry
        (tenant_id, user_id, layout_slug, tab_slug,
         widget_positions, is_default)
      VALUES
        (t.tenant_id, NULL, 'billing_home', 'default',
         '[
            {"slug": "ai_usage_my_matters", "col": 1, "span": 12, "row": 1},
            {"slug": "ai_usage_firm",        "col": 1, "span": 12, "row": 2},
            {"slug": "ai_unallocated_review","col": 1, "span": 6,  "row": 3}
         ]'::jsonb,
         TRUE);
    ELSE
      -- Append any missing widgets
      new_positions := existing;
      IF NOT (existing @> '[{"slug": "ai_usage_my_matters"}]'::jsonb) THEN
        new_positions := new_positions ||
          '[{"slug": "ai_usage_my_matters", "col": 1, "span": 12, "row": 10}]'::jsonb;
      END IF;
      IF NOT (existing @> '[{"slug": "ai_usage_firm"}]'::jsonb) THEN
        new_positions := new_positions ||
          '[{"slug": "ai_usage_firm", "col": 1, "span": 12, "row": 11}]'::jsonb;
      END IF;
      IF NOT (existing @> '[{"slug": "ai_unallocated_review"}]'::jsonb) THEN
        new_positions := new_positions ||
          '[{"slug": "ai_unallocated_review", "col": 1, "span": 6, "row": 12}]'::jsonb;
      END IF;

      UPDATE layout_registry
         SET widget_positions = new_positions
       WHERE TRIM(tenant_id) = TRIM(t.tenant_id)
         AND layout_slug = 'billing_home'
         AND tab_slug = 'default'
         AND is_default = TRUE
         AND user_id IS NULL;
    END IF;
  END LOOP;
END$$;

COMMIT;
