-- =========================================================================
-- Praesidium AI Layer — Routing Seeds (Platform Defaults)
-- =========================================================================
-- Run against DB-01 (port 5432, direct) after 0044_ai_layer_foundation migration.
-- All rows have tenant_id NULL — platform defaults that apply to every tenant
-- unless overridden by a tenant-specific row.
--
-- Caps are set conservatively; adjust as real usage data accumulates.
--     matter_daily_cost_cap_usd: $5.00    -- ~ $150/matter/month typical
--     tenant_daily_cost_cap_usd: $100.00  -- firm-wide guardrail
-- =========================================================================

BEGIN;

-- -------------------------------------------------------------------------
-- Billing module — intake document analysis (billing/api/intake_api.py)
-- -------------------------------------------------------------------------
INSERT INTO ai_model_routing
  (tenant_id, module, purpose,
   primary_model, fallback_model, max_tokens,
   matter_daily_cost_cap_usd, tenant_daily_cost_cap_usd,
   warning_thresholds, override_policy, status)
VALUES
  (NULL, 'billing', 'intake_analyze',
   'claude-sonnet-4-20250514', 'claude-haiku-4-5-20251001', 1500,
   5.00, 100.00,
   '[0.75, 0.90]'::jsonb,
   '{"allow_override": true,
     "roles": ["admin", "super_admin"],
     "require_reason": true,
     "max_override_multiplier": 3.0,
     "bill_overage_to_matter": true}'::jsonb,
   'published');

-- -------------------------------------------------------------------------
-- Admin module — timesheet reconciliation (admin/timesheet_api.py)
-- -------------------------------------------------------------------------
INSERT INTO ai_model_routing
  (tenant_id, module, purpose,
   primary_model, fallback_model, max_tokens,
   matter_daily_cost_cap_usd, tenant_daily_cost_cap_usd,
   warning_thresholds, override_policy, status)
VALUES
  (NULL, 'admin', 'timesheet_reconcile',
   'claude-sonnet-4-20250514', 'claude-haiku-4-5-20251001', 2000,
   5.00, 100.00,
   '[0.75, 0.90]'::jsonb,
   '{"allow_override": true,
     "roles": ["admin", "super_admin"],
     "require_reason": true,
     "max_override_multiplier": 3.0,
     "bill_overage_to_matter": false}'::jsonb,
   'published');

-- -------------------------------------------------------------------------
-- eDiscovery — matter chat (ediscovery/routes/chat.py — two call sites)
-- -------------------------------------------------------------------------
INSERT INTO ai_model_routing
  (tenant_id, module, purpose,
   primary_model, fallback_model, max_tokens,
   matter_daily_cost_cap_usd, tenant_daily_cost_cap_usd,
   warning_thresholds, override_policy, status)
VALUES
  (NULL, 'ediscovery', 'matter_chat',
   'claude-sonnet-4-20250514', 'claude-haiku-4-5-20251001', 2048,
   10.00, 100.00,
   '[0.75, 0.90]'::jsonb,
   '{"allow_override": true,
     "roles": ["attorney", "admin", "super_admin"],
     "require_reason": true,
     "max_override_multiplier": 3.0,
     "bill_overage_to_matter": true}'::jsonb,
   'published');

-- -------------------------------------------------------------------------
-- eDiscovery — tag intelligence recommendation (ediscovery/tag_intelligence.py)
-- High volume: ran per-document. Haiku by default, Sonnet fallback (inverted).
-- This demonstrates that "fallback" can mean "escalate" as well as "downshift"
-- depending on workflow; the adapter does not assume direction.
-- -------------------------------------------------------------------------
INSERT INTO ai_model_routing
  (tenant_id, module, purpose,
   primary_model, fallback_model, max_tokens,
   matter_daily_cost_cap_usd, tenant_daily_cost_cap_usd,
   warning_thresholds, override_policy, status)
VALUES
  (NULL, 'ediscovery', 'tag_suggest',
   'claude-haiku-4-5-20251001', NULL, 512,
   10.00, 100.00,
   '[0.75, 0.90]'::jsonb,
   '{"allow_override": false}'::jsonb,
   'published');

-- -------------------------------------------------------------------------
-- Future Session 2a entries — scoped, not yet wired.
-- Seeded now so Constraint #11 coverage is pre-established.
-- -------------------------------------------------------------------------

-- Drafting engine (M4) — main drafting workflow
INSERT INTO ai_model_routing
  (tenant_id, module, purpose,
   primary_model, fallback_model, max_tokens,
   matter_daily_cost_cap_usd, tenant_daily_cost_cap_usd,
   warning_thresholds, override_policy, status)
VALUES
  (NULL, 'drafting', 'document_draft',
   'claude-sonnet-4-20250514', 'claude-haiku-4-5-20251001', 4096,
   20.00, 200.00,
   '[0.75, 0.90]'::jsonb,
   '{"allow_override": true,
     "roles": ["attorney", "admin", "super_admin"],
     "require_reason": true,
     "max_override_multiplier": 2.0,
     "bill_overage_to_matter": true}'::jsonb,
   'published');

-- Issue map engine (M5i)
INSERT INTO ai_model_routing
  (tenant_id, module, purpose,
   primary_model, fallback_model, max_tokens,
   matter_daily_cost_cap_usd, tenant_daily_cost_cap_usd,
   warning_thresholds, override_policy, status)
VALUES
  (NULL, 'ediscovery', 'issue_map_build',
   'claude-sonnet-4-20250514', 'claude-haiku-4-5-20251001', 4096,
   15.00, 200.00,
   '[0.75, 0.90]'::jsonb,
   '{"allow_override": true,
     "roles": ["attorney", "admin", "super_admin"],
     "require_reason": true,
     "max_override_multiplier": 2.0,
     "bill_overage_to_matter": true}'::jsonb,
   'published');

-- Knowledge graph extraction (M5i)
INSERT INTO ai_model_routing
  (tenant_id, module, purpose,
   primary_model, fallback_model, max_tokens,
   matter_daily_cost_cap_usd, tenant_daily_cost_cap_usd,
   warning_thresholds, override_policy, status)
VALUES
  (NULL, 'ediscovery', 'kg_extract',
   'claude-haiku-4-5-20251001', 'claude-sonnet-4-20250514', 2048,
   15.00, 200.00,
   '[0.75, 0.90]'::jsonb,
   '{"allow_override": false}'::jsonb,
   'published');

-- WIAM findings scan (M5i)
INSERT INTO ai_model_routing
  (tenant_id, module, purpose,
   primary_model, fallback_model, max_tokens,
   matter_daily_cost_cap_usd, tenant_daily_cost_cap_usd,
   warning_thresholds, override_policy, status)
VALUES
  (NULL, 'ediscovery', 'wiam_scan',
   'claude-sonnet-4-20250514', 'claude-haiku-4-5-20251001', 4096,
   20.00, 200.00,
   '[0.75, 0.90]'::jsonb,
   '{"allow_override": true,
     "roles": ["attorney", "admin", "super_admin"],
     "require_reason": true,
     "max_override_multiplier": 2.0,
     "bill_overage_to_matter": true}'::jsonb,
   'published');

COMMIT;
